import Loader from './Loader';
import Content from './Content';

export {
    Loader,
    Content
}