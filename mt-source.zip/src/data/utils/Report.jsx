const Report = () => window.open('https://github.com/benkco/muslim-tab');
export default Report;
