const English = {
  mt: 'Muslim Tab',
  language: 'Language',
  screenshot: "Screen",
  copy: 'Copy',
  copied: 'Copied',
  random: 'Random',
  donate: 'Donate',
  rate: 'Rate',
  verses: 'Verses',
  hadiths: 'Hadiths',
  quotes: 'Quotes',
  en: 'English',
  sq: 'Albanian',
  git: 'GitHub',
};

export default English;
