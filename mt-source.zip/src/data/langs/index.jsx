import English from "./English";
import Shqip from "./Shqip";

export {
    English,
    Shqip
}