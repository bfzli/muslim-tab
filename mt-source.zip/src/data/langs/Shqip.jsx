const Shqip = {
  mt: 'Muslim Tab',
  language: 'Gjuha',
  screenshot: "Foto",
  copy: 'Kopjo',
  copied: 'Kopjuar',
  random: 'Tjetra',
  donate: 'Dhuro',
  rate: 'Vlerëso',
  verses: 'Ajete',
  hadiths: 'Hadithe',
  quotes: 'Thënje',
  en: 'Anglisht',
  sq: 'Shqip',
  git: 'GitHub',
};

export default Shqip;
