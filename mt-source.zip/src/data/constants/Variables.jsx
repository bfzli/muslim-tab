const Variables = {
    patreon: 'https://www.patreon.com/muslimtab',
    benkco: 'https://benkco.io',
    wallpaper: 'https://api.muslim-tab.com/',
    google: 'https://chrome.google.com/webstore/detail/muslim-tab-islamic-remind/jjnohnifpemmdnbidcgcojdjfabfocgm',
    firefox: 'https://addons.mozilla.org/en-US/firefox/addon/muslim-tab',
    opera: 'https://chrome.google.com/webstore/detail/muslim-tab-islamic-remind/jjnohnifpemmdnbidcgcojdjfabfocgm',
    edge: 'https://microsoftedge.microsoft.com/addons/detail/muslim-tab-islamic-remi/afgmjcggmedjodhagihcebmjlmcdcnfa',
    brave: 'https://chrome.google.com/webstore/detail/muslim-tab-islamic-remind/jjnohnifpemmdnbidcgcojdjfabfocgm',
}

export default Variables;