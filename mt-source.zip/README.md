# Muslim Tab (Extension for Browsers)

![Muslim Tab](./assets/thumb.png)

Islamic reminders on each tab you open, simple, just install the extension and start reminding yourself. Muslim Tab now is an Open Source project that everyone can contribute in its content also on the development part.

Chrome Extension - https://bit.ly/muslim-tab-chrome <br />
Firefox Add-on - https://mzl.la/3ArRDnZhttps://mzl.la/3ArRDnZ <br />
Edge Add-on - https://bit.ly/muslim-tab-edge <br />
Discord Server - https://bit.ly/muslim-tab-discord <br />
Product Launch - https://bit.ly/muslim-tab-product-hunt <br />
Monthly Contribution - https://www.patreon.com/muslimtab <br />
One Time Contribution - https://buymeacoffee.com/muslimtab <br />